(* Simply supported beam: load (x/length)^power, constant flexural rigidity. *)
Clear[beamDeflection, x, length, load, rigidity];
beamDeflection[power_Integer] := Module[{y},
    Factor[DSolveValue[{
        rigidity y''''[x] == load (x/length)^power,
        y[0] == 0, y[length] == 0,
        y''[0] == 0, y''[length] == 0
    }, y[x], x]]
];
