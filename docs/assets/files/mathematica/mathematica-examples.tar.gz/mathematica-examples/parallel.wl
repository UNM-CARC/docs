workers = ToExpression[Environment["SLURM_CPUS_PER_TASK"]] - 1;
licenseFile = Environment["MMA_LICENSE_FILE"];

LaunchKernels[KernelConfiguration["Local",
    "KernelCommand" -> ("math -pwfile \"" <> licenseFile <> "\""),
    "KernelCount" -> workers]];
If[Length[Kernels[]] != workers, Print["Worker launch failed"]; Exit[1]];

Print["Workers: ", ParallelEvaluate[{$KernelID, $MachineName}]];
Print["Worker license servers: ", ParallelEvaluate[$LicenseServer]];
Get["beam-model.wl"];
DistributeDefinitions[beamDeflection];
midpoints = ParallelTable[
    Factor[beamDeflection[n] /. x -> length/2], {n, 0, 3}];
Print["Midpoint formulas (load powers 0 through 3): ",
    ToString[midpoints, InputForm]];
CloseKernels[];
Exit[];
