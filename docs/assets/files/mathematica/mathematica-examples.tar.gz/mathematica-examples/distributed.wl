nodes = StringSplit[RunProcess[
    {"scontrol", "show", "hostnames", Environment["SLURM_JOB_NODELIST"]},
    "StandardOutput"]];
launcher = FileNameJoin[{Directory[], "math-kernel.sh"}];

links = Table[LinkCreate[LinkProtocol -> "TCPIP"], {Length[nodes]}];
processes = Table[
    StartProcess[{
        "srun", "--exact", "--nodes=1", "--ntasks=1", "--cpus-per-task=1",
        "--nodelist=" <> nodes[[i]],
        "--output=worker-%j-%N.out", "--error=worker-%j-%N.err",
        launcher, "-subkernel", "-noinit", "-wstp",
        "-linkmode", "Connect", "-linkprotocol", "TCPIP",
        "-linkname", First[links[[i]]]
    }],
    {i, Length[nodes]}
];

TimeConstrained[LaunchKernels[links], 90, Exit[1]];
If[Length[Kernels[]] != Length[nodes], Exit[1]];

Print["Workers: ", ParallelEvaluate[{$KernelID, $MachineName}]];
Print["Worker license servers: ", ParallelEvaluate[$LicenseServer]];
Get["beam-model.wl"];
DistributeDefinitions[beamDeflection];
midpoints = ParallelTable[
    Factor[beamDeflection[n] /. x -> length/2], {n, 0, 3}];
Print["Midpoint formulas (load powers 0 through 3): ",
    ToString[midpoints, InputForm]];

Scan[LinkWrite[#, Unevaluated[EvaluatePacket[Quit[0]]]] &, links];
TimeConstrained[
    While[AnyTrue[processes, ProcessStatus[#] === "Running" &], Pause[0.1]],
    20, Exit[1]
];
codes = ProcessInformation[#, "ExitCode"] & /@ processes;
CloseKernels[];
If[codes =!= ConstantArray[0, Length[nodes]], Exit[1]];
Exit[];
