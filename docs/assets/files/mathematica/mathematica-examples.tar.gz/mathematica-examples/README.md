# Mathematica on Easley

Mathematica combines symbolic mathematics with numerical computing. This tutorial
uses that combination to distribute symbolic derivations across CPUs and nodes,
then evaluate many load combinations on a GPU.

The distinguishing feature is the workflow: solve differential equations with
symbolic parameters, manipulate the resulting formulas, and then evaluate them
numerically in the same language. MATLAB, Julia and R also have symbolic tools;
this example highlights Mathematica's built-in symbolic solver.

## Files and setup

Download the archive, extract it, and work in that directory on Easley. Keep
it on a filesystem accessible from compute nodes:

```bash
tar -xzf mathematica-examples.tar.gz
cd mathematica-examples
module load mathematica/15.0.1
chmod +x math-kernel.sh
```

Run the jobs below one at a time. The shared `math-kernel.sh` launcher supplies
the license information to both the controller and workers:

```bash
#!/bin/bash
# Use the same license server for the controller and every worker.
# Replace neutrino.phys.unm.edu with your license server's FQDN.
exec math -pwfile <(printf '!neutrino.phys.unm.edu\n') "$@"
```

`neutrino.phys.unm.edu` is an example. Please substitute the fully qualified
hostname of your Mathematica license server. This launcher uses Bash process
substitution to provide a transient license file, then forwards the worker's
arguments. Mathematica's [kernel documentation](https://reference.wolfram.com/language/ref/program/WolframKernel.html)
describes `-pwfile`.

## The example: derive a beam-deflection formula

For a simply supported beam, the small-deflection model is

```text
rigidity × y''''(x) = load × (x/length)^n
```

Here, `y(x)` is downward deflection, `length` is the beam length, `load` is
the load intensity scale, and `rigidity` is the flexural rigidity (E × I).
The ends have zero deflection and zero bending moment. Setting `n = 0` gives
a uniform load; `n = 1` gives a linearly increasing load.

The shared input [`beam-model.wl`](beam-model.wl) asks Mathematica to derive
the formula without assigning numerical values to these parameters:

```wolfram
(* Simply supported beam: load (x/length)^power, constant flexural rigidity. *)
Clear[beamDeflection, x, length, load, rigidity];
beamDeflection[power_Integer] := Module[{y},
    Factor[DSolveValue[{
        rigidity y''''[x] == load (x/length)^power,
        y[0] == 0, y[length] == 0,
        y''[0] == 0, y''[length] == 0
    }, y[x], x]]
];
```

`DSolveValue` solves the differential equation and its boundary conditions.
`Factor` simplifies the resulting polynomial. For a uniform load, the exact
midpoint deflection is:

```text
5 × load × length^4 / (384 × rigidity)
```

This formula describes a whole family of beams and loads, rather than one
numerical case.

## 1. Multiple CPUs on one node

[`parallel.wl`](parallel.wl) launches two local workers and gives them the
definition from `beam-model.wl`. `ParallelTable` derives midpoint formulas
for load powers 0, 1, 2 and 3. It also prints each worker's hostname and license
server.

Save [`mathematica_multicpu.sbatch`](mathematica_multicpu.sbatch):

```bash
#!/bin/bash -l
#SBATCH --job-name=mathematica-multicpu
#SBATCH --partition=debug
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=3
#SBATCH --mem=4G
#SBATCH --time=00:05:00
#SBATCH --output=%x-%j.out

module load mathematica/15.0.1
cd "$SLURM_SUBMIT_DIR"
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1

srun ./math-kernel.sh -script parallel.wl
```

Submit:

```bash
sbatch mathematica_multicpu.sbatch
```

Three CPUs provide one for the controller and two for workers. The thread
settings limit each worker's math libraries to one thread. To request more
workers, increase `--cpus-per-task`; the input reserves one CPU for the
controller. Available licenses also limit the worker count.

The output includes two workers on the same node and these four exact formulas:

```text
{5 load length^4/(384 rigidity),
 5 load length^4/(768 rigidity),
 89 load length^4/(23040 rigidity),
 13 load length^4/(5120 rigidity)}
```

## 2. Multiple nodes

[`distributed.wl`](distributed.wl) performs the same four derivations, using
one worker on each of two nodes. It uses Slurm to start the workers and
Mathematica's WSTP protocol to connect them to the controller.

Save [`mathematica_multinode.sbatch`](mathematica_multinode.sbatch):

```bash
#!/bin/bash -l
#SBATCH --job-name=mathematica-multinode
#SBATCH --partition=debug
#SBATCH --nodes=2
#SBATCH --ntasks-per-node=2
#SBATCH --cpus-per-task=1
#SBATCH --mem=4G
#SBATCH --time=00:05:00
#SBATCH --output=%x-%j.out

module load mathematica/15.0.1
cd "$SLURM_SUBMIT_DIR"
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1

./math-kernel.sh -script distributed.wl
```

Submit:

```bash
sbatch mathematica_multinode.sbatch
```

The controller runs directly in the batch step. The input starts separate
`srun` steps for its workers; adding `srun` in front of the controller would
start duplicate controllers. Each worker uses the same shared license launcher.

Expect the same formulas as above, but worker hostnames on **two different
nodes**. Worker messages are saved in `worker-*.out` and `worker-*.err`.
The input includes a connection timeout and closes workers before exiting.

## 3. GPU evaluation

The GPU example uses the symbolic formulas as input to a numerical calculation.
It does not run the symbolic differential-equation solver on the GPU.

[`gpu.wl`](gpu.wl) first derives four beam-response formulas on the CPU.
It sets `length = load = rigidity = 1` to obtain normalized response shapes,
then samples them at 256 positions. It combines the shapes using 1,024 sets
of load coefficients:

```wolfram
gpuResult = CUDADot[shapeMatrix, coefficients];
```

This GPU matrix multiplication produces the deflection at every position for
every load combination. Superposition applies because the beam equation is
linear. The example compares the GPU result with a CPU multiplication and
prints the maximum difference. See Wolfram's
[`CUDADot` documentation](https://reference.wolfram.com/language/CUDALink/ref/CUDADot.html).

Save [`mathematica_gpu.sbatch`](mathematica_gpu.sbatch):

```bash
#!/bin/bash -l
#SBATCH --job-name=mathematica-gpu
#SBATCH --partition=debug
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --gpus-per-node=1
#SBATCH --mem=4G
#SBATCH --time=00:05:00
#SBATCH --output=%x-%j.out

module load mathematica/15.0.1
cd "$SLURM_SUBMIT_DIR"

srun ./math-kernel.sh -script gpu.wl
```

Submit:

```bash
sbatch mathematica_gpu.sbatch
```

Expect result dimensions `{256, 1024}` and a maximum CPU/GPU difference close
to zero. Small floating-point differences are normal. This example checks the
CPU-to-GPU workflow; a small workload may be faster on the CPU.

On first use, CUDALink may download supporting software into your Wolfram cache.
This can add startup time.

## Read the results

`sbatch` prints the job number. Check progress with:

```bash
squeue --me
```

Each job writes `mathematica-<mode>-<jobid>.out` in the submission directory.
For example:

```bash
cat mathematica-multicpu-1235085.out
```

Use your own job number. If a job reports `No valid password found`, check the
hostname in `math-kernel.sh` and license availability. If a two-node debug job
is pending with `QOSMaxNodePerUserLimit`, let your other debug jobs finish.

## Further reading

- [Wolfram Language](https://reference.wolfram.com/language/)
- [Parallel kernel configuration](https://reference.wolfram.com/language/ref/KernelConfiguration.html)
- [CUDALink](https://reference.wolfram.com/language/CUDALink/tutorial/Overview.html)
- [Slurm introduction](https://github.com/UNM-CARC/QuickBytes/blob/master/Intro_to_slurm.md)
