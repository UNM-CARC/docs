Get["beam-model.wl"];
Needs["CUDALink`"];
If[!TrueQ[CUDAQ[]], Print["CUDA unavailable"]; Exit[1]];

(* Derive exact responses for four polynomial loads, then normalize the units. *)
shapes = Table[
    beamDeflection[n] /. {length -> 1, load -> 1, rigidity -> 1},
    {n, 0, 3}
];
Print["Uniform-load formula: ", ToString[shapes[[1]], InputForm]];

(* Evaluate at 256 positions for 1024 combinations of the four loads. *)
positions = N[Subdivide[0, 1, 255]];
shapeMatrix = Table[shapes /. x -> position, {position, positions}];
coefficients = N[Table[Sin[i j/100], {i, 1, 4}, {j, 1, 1024}]];

gpuResult = CUDADot[shapeMatrix, coefficients];
difference = Max[Abs[Flatten[gpuResult - shapeMatrix.coefficients]]];
Print["License server: ", $LicenseServer];
Print["Result dimensions: ", Dimensions[gpuResult]];
Print["Maximum difference from CPU: ", difference];
If[difference > 10^-10, Exit[1]];
Exit[];
