#!/bin/bash
# Use the same license server for the controller and every worker.
exec math -pwfile <(printf '!neutrino.phys.unm.edu\n') "$@"
